import os

#This opens up the files so that the user see a much more friendly command prompt
os.system("start appearlydev.py")