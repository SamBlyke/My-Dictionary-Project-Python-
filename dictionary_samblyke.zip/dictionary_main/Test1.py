#d={"abc":"first 3 letter ","def":"letter from position 4th to 6th","ghi":"letters from position 7th to 9th"}
import json
import os
import time
from difflib import get_close_matches

d=json.load(open("data.json"));#dd=json.load(open("dictionary.json"));#ddd=json.load(open("dictionary_compact.json"));dddd=json.load(open("dictionary_alpha_arrays.json"))
#d.update(dd);#d.update(ddd);d.update(dddd)
with open(r"temp.txt") as file_history:
    #sww=file_history.readlines()
    s=file_history.read()
j=0
i=0
s=s.lower()
sl=list(s)
sw=""
key=0;p=None
lis=list(d.keys())
if s not in lis:
    for i in sl:               
        sw=sw+i  
        j=0 
        for j in lis:  
            if(sw==j):
                key=1
                p=j
                break
        if(key==1):
            p=j
            break
    #print(key)
    #print(i," ",j)
    #print(list(d.keys()))

    ans=str(input(("Did you mean ",p," ? [Y/N]" )))
    ans=ans.upper()
    if ans=="Y":
        with open("dictionary_history.txt","a+") as file_history:
            file_history.write(p)
        print(d[p])
        time.sleep(5)
        #os.system("start appearlydev.py")
    elif(ans=="N"):
        ap=get_close_matches(s,list(d.keys()))
        l=len(ap)
        l=l-1
        print("Did you mean any of these %s by" % ap,s,"?")
        inp=int(input("Enter the number of the word {Starting from 0 ending till 5. If its not any of the word then enter N. - "))
        inp=inp-1
        if(inp!=9):
            print(ap[inp])
            for i in d[ap[inp]]:
                print(ap[inp].capitalize()," --> ",i)
            ap=input("Press Enter to quit ")
            if(ap==""):
                time.sleep(1)
            else:
                print("Still quiting")
                time.sleep(1)
        elif(inp!="N" and "n" and 1 and 2 and 3 and 4 and 5):
            print("Input not correct")
            time.sleep(2)
        elif(inp=="N" or "n"):
            print("sorry No defination found for your word then")
            time.sleep(2)
        #os.system("start appearlydev.py")
else:
    print(d[s])
    time.sleep(5)
    #os.system("start appearlydev.py")
with open("dictionary_history.text","a+") as file_history:
    file_history.write(ap[inp])

