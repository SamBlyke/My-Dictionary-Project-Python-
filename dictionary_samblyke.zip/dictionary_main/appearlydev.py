import json
import os


data=json.load(open("data.json"));#dd=json.load(open("dictionary.json"));#ddd=json.load(open("dictionary_compact.json"));dddd=json.load(open("dictionary_alpha_arrays.json"))
#data.update(dd);#data.update(ddd);data.update(dddd)
print("Dictionary successfully loaded. Starting the app now.")

w=None

def dictionary():
    while True:
        a=new_word()
        if a in data:
            for i in data[a]:
                print(a.capitalize()," --> ",i)
                #if(type(data[a]==list and len(data[a])>1)):
                    #print(a.capitalize()," --> ",i)
                #else:
                    #print(a.capitalize()," --> ",value(data[a]))
            with open("dictionary_history.txt","a+") as dict_history:
                dict_history.write(a)
                dict_history.write("\n")
        elif a=='/e':
            print("EXITING NOW")
            break
        else:
            with open(r"temp.txt","w") as tempo:
                tempo.write(a)
                tempo.write("\n")
            os.system("start Test1.py")
            continue
            
        
def new_word():
    print(r"TO EXIT TYPE /e")
    w=input(":Enter the word : ")
    if(w!="/e"):
        w=w.lower()
        w=w.strip()
        return w
    elif(w=="/e"):
        print("EXITING NOW")

dictionary()
    

